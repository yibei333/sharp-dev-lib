---
name: sharp-dev-lib
description: This skill should be used when working on the SharpDevLib project — a .NET Standard 2.0 utility library providing encoding, hashing, JSON, compression, cryptography (RSA/JWT/X509), HTTP, TCP/UDP, email, Excel, SQL helpers and more. It provides module-by-module API references, document style guides, and project conventions to help write code, docs, or tests consistently.
---

# SharpDevLib Skill

## 概述

SharpDevLib 是一个基于 `.NET Standard 2.0` 的 C# 工具库，提供编码、哈希、JSON、压缩、加解密、HTTP、TCP/UDP、邮件、Excel、SQL 等常用功能的封装，面向中文开发者。

当需要完成以下任务时使用本 skill：
- 为项目添加新功能或修改已有模块
- 编写或更新 `doc/` 下的功能文档
- 为 `SharpDevLib.Tests/` 补充单元测试
- 查阅某个模块的 API 设计与参数约定

详细的 API 参考请查阅 `references/api_reference.md`。

---

## 项目结构

```
sharp-dev-lib/
├── src/
│   ├── SharpDevLib/          # 主库
│   │   ├── Basic/            # 编码、哈希、JSON、集合、字符串、文件、枚举、反射、时间、树、克隆、DataTable、NullCheck、模型
│   │   ├── Compression/      # 压缩/解压缩（zip/tar/gz/bz2/rar/7z/xz）
│   │   ├── Cryptography/     # 对称加密、RSA、JWT、PEM、X509
│   │   ├── Data/             # SqlHelper（SQLite/MSSQL/MySQL）
│   │   ├── OpenXML/Excel/    # Excel 读写、样式、加密
│   │   └── Transport/        # Email、Http、Tcp、Udp
│   └── SharpDevLib.Tests/    # 单元测试
└── doc/                      # 各模块 Markdown 文档（41 个）
```

---

## 文档编写规范

`doc/` 下的所有文档遵循统一风格，新增或修改文档时必须遵守：

1. **文件头**：`# 功能名称`，紧接一两句中文说明。
2. **代码示例为核心**：每个方法直接给出 ` ```csharp ``` ` 代码块；输出结果以 `//打印:xxx` 形式内嵌在代码注释中，不单独用文字描述输出。
3. **复杂功能先简后全**：先给「简单示例」代码块，再给「完整示例」代码块，展示所有参数。
4. **参数表**：对象参数较多时用 Markdown 表格列出「参数名 | 类型 | 说明」，放在代码块之前。
5. **末尾必须有 `## 相关文档`**：用相对链接 `[文档名](文件名.md)` 列出关联模块。
6. **全程中文**：注释、说明均使用中文，类名/方法名保持 PascalCase 英文。

---

## 代码开发规范

- **目标框架**：`netstandard2.0`，语言版本 `C# 12.0`；新代码不得使用高于此框架的 API。
- **命名空间**：与目录结构对应，根命名空间为 `SharpDevLib`。
- **公共 API 必须有 XML 文档注释**（`/// <summary>`）。
- **Helper 类**：采用静态类 + 静态方法或扩展方法模式，不引入实例状态（除非必须）。
- **异常**：使用项目已有的自定义异常类（如 `CompressFormatNotSupportedException`）；必要时新增，继承 `Exception`。
- **测试**：在 `SharpDevLib.Tests/` 中对应目录下添加 `[功能]Tests.cs`，每个公共方法至少一个测试用例。

---

## 各模块速查

| 模块 | 命名空间 / 核心类 | 关键方法示例 |
|------|-----------------|-------------|
| **Base64** | `Base64EncodeHelper` | `Encode(string)` / `Decode(string)` |
| **Hex** | `HexStringHelper` | `ToHexString(byte[])` / `ToBytes(string)` |
| **MD5** | `Md5Helper` | `Hash(string)` / `HashFile(string)` |
| **SHA** | `ShaHelper` | `Sha256(string)` / `HmacSha256(string, string)` |
| **JSON** | `JsonHelper` | `Serialize(obj)` / `Deserialize<T>(json)` |
| **字符串** | `StringHelper` | `IsNullOrWhiteSpace` / `Format` / `Truncate` |
| **文件** | `FileHelper` | `Read` / `Write` / `Copy` / `Delete` / `GetSize` |
| **集合** | `EnumerableHelper` | `IsNullOrEmpty` / `ToTree` / `Paginate` |
| **反射** | `ReflectionHelper` | `GetProperties` / `GetValue` / `SetValue` |
| **时间** | `TimeHelper` | `ToTimestamp` / `FromTimestamp` |
| **树** | `TreeHelper` | `Build<T>` |
| **压缩** | `CompressionHelper` | `Compress(CompressRequest)` / `DeCompress(DeCompressRequest)` |
| **对称加密** | `SymmetricAlgorithmHelper` | `Encrypt` / `Decrypt`（AES/DES/3DES） |
| **RSA** | `RsaKeyHelper` | `GenerateKeyPair` / `Encrypt` / `Decrypt` / `Sign` / `Verify` |
| **JWT** | `JwtHelper` | `Create(JwtCreateRequest)` / `Verify(JwtVerifyRequest)` |
| **X509** | `X509Helper` | `CreateSelfSigned` / `CreateFromCsr` |
| **SQL** | `SqlHelper` | `Query<T>` / `Execute` / `BulkInsert` |
| **Excel** | `ExcelHelper` / `SpreadsheetHelper` | `Read` / `Write` / `SetStyle` |
| **HTTP** | `HttpHelper` | `Get` / `Post` / `Put` / `Delete`（支持进度/重试） |
| **Email** | `EmailHelper` | `Send(EmailConfig, EmailContent)` |
| **TCP** | `TcpHelper` | `CreateServer` / `CreateClient` |
| **UDP** | `UdpHelper` | `CreateServer` / `CreateClient` |

---

## 常用模型约定

- **响应模型**：`EmptyReply` / `DataReply<T>` / `PageReply<T>`，均继承 `BaseReply`，包含 `Code`、`Message`、`Data`。
- **请求模型**：`PageRequest`（含 `PageIndex`、`PageSize`）；`IdRequest<T>`、`NameRequest` 等。
- **DTO**：`BaseDto` → `DataDto<T>` → `IdDataDto<TId, TData>` 等泛型层次。

---

## References

详细 API 文档与代码示例见：`references/api_reference.md`
