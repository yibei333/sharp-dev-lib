# SharpDevLib API Reference

> 面向 AI 使用的详细 API 参考。每个模块包含核心 API 签名与代码示例。
> 源文档位于项目 `doc/` 目录，共 41 个 `.md` 文件。

---

## 基础扩展（Basic）

### 编码（Encode）

| 类 | 方法 | 说明 |
|----|------|------|
| `Utf8EncodeHelper` | `byte[] Utf8Decode(this string)` | 字符串 → UTF-8 字节 |
| | `string Utf8Encode(this byte[])` | UTF-8 字节 → 字符串 |
| `Base64EncodeHelper` | `string Base64Encode(this byte[])` | 字节 → Base64 字符串 |
| | `byte[] Base64Decode(this string)` | Base64 字符串 → 字节 |
| `Base64UrlEncodeHelper` | `string Base64UrlEncode(this byte[])` | 字节 → Base64Url 字符串 |
| | `byte[] Base64UrlDecode(this string)` | Base64Url 字符串 → 字节 |
| `HexStringHelper` | `string ToHexString(this byte[])` | 字节 → 十六进制字符串 |
| | `byte[] HexToBytes(this string)` | 十六进制字符串 → 字节 |
| `UrlEncodeHelper` | `string UrlEncode(this string)` | URL 编码 |
| | `string UrlDecode(this string)` | URL 解码 |

---

### 哈希（Hash）

```csharp
// MD5
var hash = "hello".Md5Hash();                  // 32位小写
var hash16 = "hello".Md5Hash(Md5OutputLength.Bit16);  // 16位

// SHA
var sha256 = "hello".Sha256Hash();
var sha512 = "hello".Sha512Hash();

// HMAC
var hmacMd5 = "hello".HmacMd5Hash("key".Utf8Decode());
var hmacSha256 = "hello".HmacSha256Hash("key".Utf8Decode());

// 文件哈希
var fileHash = "file.txt".Md5FileHash();
```

---

### JSON（JsonHelper）

```csharp
// 序列化
var json = obj.Serialize();
var formattedJson = obj.Serialize(new JsonOption { FormatJson = true });

// 全局配置（只需设置一次）
JsonOption.Default.FormatJson = true;
JsonOption.Default.NameFormat = JsonNameFormat.CamelCaseLower;  // 或 PascalCase

// 反序列化
var obj = json.DeSerialize<MyClass>();
bool ok = json.TryDeSerialize<MyClass>(out var result);

// 格式化 / 压缩
var pretty = compactJson.FormatJson();
var compact = prettyJson.CompressJson();
```

**JsonOption 属性**：

| 属性 | 类型 | 说明 |
|------|------|------|
| `FormatJson` | `bool` | 序列化时格式化输出 |
| `NameFormat` | `JsonNameFormat` | 序列化命名格式（`Default`/`CamelCaseLower`） |
| `CaseInsensitive` | `bool` | 反序列化时忽略大小写 |

---

### 字符串（StringHelper）

```csharp
// 常用扩展方法示例
"hello".IsNullOrWhiteSpace();          // false
"hello world".ToPascalCase();          // HelloWorld
"HelloWorld".ToCamelCase();            // helloWorld
"hello".Repeat(3);                     // hellohellohello
"hello world".SplitToList(' ');        // ["hello","world"]
"123".ToInt();                         // 123
"3.14".ToDouble();                     // 3.14
"abc123".RemoveNonDigit();             // 123
"hello".TrimStart("hel");             // lo
"  hello  ".TrimAll();                 // hello
"aaabbb".RegexUnescape();              // Unicode 转义还原
```

---

### 文件（FileHelper）

```csharp
// 文件操作（均为扩展方法，作用于路径字符串）
"file.txt".CreateFileIfNotExist();
"dir/".CreateDirectoryIfNotExist();
"file.txt".RemoveFileIfExist();
"file.txt".RemoveDirectoryIfExist();

// 读写
byte[] bytes = "file.txt".ReadFile();
"file.txt".SaveToFile(bytes);           // byte[] → 文件
stream.SaveToFile("out.txt");           // Stream → 文件

// 文件信息
long size = "file.txt".GetFileSize();
string sizeStr = "file.txt".GetFileSizeString(); // "1.23 MB"
```

---

### 集合（EnumerableHelper）

```csharp
list.IsNullOrEmpty();
list.Paginate(pageIndex: 1, pageSize: 10);    // 返回 PageReply<T>
list.ToDataTable();                            // List<T> → DataTable
list.ForEach(item => Console.WriteLine(item));
```

---

### 树（TreeHelper）

```csharp
// T 必须实现 ITreeNode<TId> 接口（含 Id、ParentId、Children 属性）
var tree = list.BuildTree(rootParentId: 0);
// 返回根节点列表，Children 已递归填充
```

---

### 反射（ReflectionHelper）

```csharp
var props = typeof(MyClass).GetPublicProperties();
var value = obj.GetPropertyValue("Name");
obj.SetPropertyValue("Name", "张三");
var instance = typeof(MyClass).CreateInstance();
```

---

### 时间（TimeHelper）

```csharp
// DateTime ↔ Unix 时间戳（毫秒）
long ts = DateTime.Now.ToTimestamp();
DateTime dt = ts.FromTimestamp();

// 时间差描述
string desc = DateTime.Now.Subtract(someDate).ToDescription(); // "3天前"
```

---

### 空值检查（NullCheck）

```csharp
// 引发异常（若为 null/empty/whitespace）
string name = input.ThrowIfNullOrWhiteSpace("input");
Guid id = guid.ThrowIfEmpty("id");
IEnumerable<T> list = items.ThrowIfNullOrEmpty("items");
```

---

### 克隆（CloneHelper）

```csharp
var copy = obj.Clone();         // 深拷贝（基于 JSON 序列化）
```

---

### 随机数（RandomHelper）

```csharp
int n = RandomHelper.Next(1, 100);
string str = RandomHelper.NextString(length: 8);  // 随机字母数字字符串
byte[] bytes = RandomHelper.NextBytes(16);
```

---

## 模型（Model）

### DTO

| 类 | 属性 | 说明 |
|----|------|------|
| `NameDto` | `string Name` | 仅含名称 |
| `IdDto<TId>` | `TId Id` | 仅含 ID |
| `IdNameDto<TId>` | `TId Id`, `string Name` | ID + 名称 |
| `DataDto<TData>` | `TData Data` | 仅含数据 |
| `IdDataDto<TId,TData>` | `TId Id`, `TData Data` | ID + 数据 |
| `IdNameDataDto<TId,TData>` | `TId Id`, `string Name`, `TData Data` | ID + 名称 + 数据 |

### Request

| 类 | 属性 | 说明 |
|----|------|------|
| `PageRequest` | `int PageIndex`, `int PageSize` | 分页请求基类 |
| `IdRequest<TId>` | `TId Id` | 含 ID |
| `NameRequest` | `string Name` | 含名称 |
| `DataRequest<TData>` | `TData Data` | 含数据 |
| `IdDataRequest<TId,TData>` | `TId Id`, `TData Data` | ID + 数据 |

### Reply

```csharp
// EmptyReply（无数据响应）
new EmptyReply(code: 0, message: "success");

// DataReply<T>（含数据响应）
new DataReply<string>(code: 0, message: "ok", data: "hello");

// PageReply<T>（分页响应）
new PageReply<MyItem>(code: 0, message: "ok", data: items, total: 100);
// 属性：Code, Message, Data, Total, PageIndex, PageSize, TotalPage
```

---

## 压缩/解压缩（Compression）

### 压缩

支持格式：`.zip` / `.tar` / `.tgz` / `.gz` / `.bz2`

```csharp
// 简单示例
var request = new CompressRequest(["data.txt", "folder/"], "backup.zip");
await request.CompressAsync();

// 完整示例
var request = new CompressRequest(["./data1.txt", "./folder1"], "backup.zip")
{
    Password = "foo",               // 仅 zip 支持密码
    IncludeSourceDiretory = true,   // 是否保持文件夹结构
    Level = CompressionLevel.Normal,
    CancellationToken = cts.Token,
    OnProgress = args => Console.WriteLine($"[{args.ProgressText}] {args.CurrentName}")
};
await request.CompressAsync();
```

### 解压缩

支持格式：`.zip` / `.rar` / `.7z` / `.tar` / `.tgz` / `.gz` / `.xz` / `.bz2`

```csharp
// 简单示例
var request = new DeCompressRequest("data.zip", "./output");
await request.DeCompressAsync();

// 完整示例（带密码和进度）
var request = new DeCompressRequest("backup.zip", "./output")
{
    Password = "foo",
    OnProgress = p => Console.WriteLine(p.ProgressText)
};
await request.DeCompressAsync();
```

---

## 加解密（Cryptography）

### 对称加密（SymmetricAlgorithmHelper）

支持算法：AES（16/24/32 字节密钥）、DES（8 字节）、3DES（16/24 字节）

```csharp
using System.Security.Cryptography;

using var aes = Aes.Create();
aes.Mode = CipherMode.CBC;
aes.Padding = PaddingMode.PKCS7;
aes.SetKeyAutoPad("0123456789ABCDEF0123456789ABCDEF".Utf8Decode());  // 自动补齐密钥
aes.SetIVAutoPad("0123456789ABCDEF".Utf8Decode());                    // 自动补齐 IV

// 加密/解密字节数组
byte[] encrypted = aes.Encrypt("Hello World".Utf8Decode());
byte[] decrypted = aes.Decrypt(encrypted);

// 加密/解密流
aes.Encrypt(inputStream, outputStream);
aes.Decrypt(inputStream, outputStream);
```

### RSA 密钥（RsaKeyHelper）

```csharp
using System.Security.Cryptography;

// 生成密钥对并导出 PEM
using var rsa = RSA.Create(2048);
string privateKey = rsa.ExportPem(PemType.Pkcs1PrivateKey);   // PKCS#1
string publicKey  = rsa.ExportPem(PemType.X509SubjectPublicKey);

// 导入 PEM
rsa.ImportPem(privateKey);
rsa.ImportPem(publicKey);

// PemType 枚举值：
// Pkcs1PrivateKey / Pkcs1PublicKey / Pkcs8PrivateKey / X509SubjectPublicKey
// EncryptedPkcs8PrivateKey（带密码）

// 带密码的 PKCS#8
string encPem = rsa.ExportPem(PemType.EncryptedPkcs8PrivateKey, "password");
```

### JWT（JwtHelper）

```csharp
var payload = new { id = 1, name = "张三" };

// HS256（HMAC SHA256）
string token = JwtHelper.CreateWithHmacSha256(payload, "secret".Utf8Decode());
JwtVerifyResult result = JwtHelper.VerifyWithHmacSha256(token, "secret".Utf8Decode())
                                  .EnsureVerified();  // 验证失败则抛异常

// RS256（RSA SHA256）
string token2 = JwtHelper.CreateWithRsaSha256(payload, privateKeyPem);
JwtVerifyResult result2 = JwtHelper.VerifyWithRsaSha256(token2, publicKeyPem);

// JwtVerifyResult 属性：IsVerified, Algorithm, Header, Payload, Signature
Console.WriteLine(result.Payload!.RegexUnescape());  // 还原 Unicode 转义
```

### X.509 证书（X509Helper）

```csharp
// 自签名根证书
var rootCert = X509Helper.CreateSelfSignedCertificate(new TBSCertificate
{
    Subject = new X509Subject { CommonName = "MyRootCA" },
    NotBefore = DateTimeOffset.Now,
    NotAfter = DateTimeOffset.Now.AddYears(10),
    IsCA = true
});

// CSR → 证书
var csr = X509CertificateSigningRequest.Create(subject, keyPair);
var cert = X509Helper.CreateFromCsr(csr, issuerCert, issuerKey);

// 导出 PFX / PEM
byte[] pfx = rootCert.Export(X509ContentType.Pfx, "password");
string pemChain = rootCert.ExportCertificatePem();
```

---

## 数据库（SqlHelper）

```csharp
// 初始化（全局一次）
SqlHelper.Config(SqliteFactory.Instance, "data source=mydb.db");
// SQL Server: SqlHelper.Config(SqlClientFactory.Instance, connectionString);
// MySQL:      SqlHelper.Config(MySqlConnectorFactory.Instance, connectionString);

var sqlHelper = new SqlHelper();

// 执行非查询
sqlHelper.ExecuteNonQuery("INSERT INTO Users VALUES(1,'张三',20)");

// 标量查询
int count = sqlHelper.ExecuteScalar<int>("SELECT COUNT(1) FROM Users");

// 列表查询（列名需与属性名或 DTO 属性对应）
List<MyDto> list = sqlHelper.Query<MyDto>("SELECT Id, Name FROM Users");

// DataTable / DataSet
DataTable table = sqlHelper.ExecuteDataTable("SELECT * FROM Users");
DataSet set = sqlHelper.ExecuteDataSet("SELECT ...; SELECT ...;");

// 事务
var tx = sqlHelper.Connection.BeginTransaction();
try { /* ... */ tx.Commit(); }
catch { tx.Rollback(); }
```

---

## Excel（ExcelHelper / SpreadsheetHelper）

### ExcelHelper（简单读写）

```csharp
// 写入
using var stream = new MemoryStream();
ExcelHelper.Write(dataTable, stream);   // DataTable → Excel
ExcelHelper.Write(dataSet, stream);     // DataSet  → Excel（多 Sheet）
stream.SaveToFile("output.xlsx");

// 读取
using var stream = new FileInfo("file.xlsx").OpenRead();
DataTable table = ExcelHelper.ReadTable(stream);
DataSet set = ExcelHelper.ReadSet(stream);
// 自定义列名映射：ReadSet(stream, ["显示名1","显示名2"], ["ColA","ColB"])

// 加密/解密
ExcelHelper.Encrypt(inputStream, outputStream, "password");
ExcelHelper.Decrypt(inputStream, outputStream, "password");
```

### SpreadsheetHelper（高级操作）

用于精细控制单元格样式、合并、批注、图片插入等，参见 `doc/spreadsheet.md`。

---

## HTTP（HttpHelper）

### 全局配置

```csharp
HttpHelper.SetConfig("clientId", new HttpConfig
{
    Timeout = TimeSpan.FromSeconds(30),
    RetryCount = 3,
    UserAgent = null,  // null 则使用默认 UA
    OnSendProgress = p => Console.WriteLine($"{p.ProgressString} {p.Speed}"),
    OnReceiveProgress = p => Console.WriteLine($"{p.ProgressString} {p.Speed}")
});
```

### GET

```csharp
// 简单
var response = await HttpHelper.NewRequest("https://api.example.com/data").GetAsync();

// 完整
var response = await HttpHelper
    .NewRequest("https://api.example.com/users")
    .UseClientId("clientId")
    .AddHeader("Authorization", ["Bearer token"])
    .AddCookie(new Cookie("session", "abc"))
    .AddParameter("page", "1")
    .GetAsync()
    .EnsureSuccessStatusCode();

string text = await response.ReadAsStringAsync();
MyClass obj = await response.GetResponseDataAsync<MyClass>();
Stream stream = await response.ReadAsStreamAsync();
```

### POST

```csharp
// JSON Body
var response = await HttpHelper
    .NewRequest("https://api.example.com/users")
    .AddJson(payload.Serialize())
    .PostAsync();

// Form Data
var response = await HttpHelper
    .NewRequest("https://api.example.com/upload")
    .AddParameter("name", "张三")
    .PostAsync();

// Multipart（文件上传）
var response = await HttpHelper
    .NewRequest("https://api.example.com/upload")
    .AddFile(new HttpFormFile("file", "test.txt", fileBytes))
    .PostAsync();
```

### PUT

```csharp
var response = await HttpHelper
    .NewRequest("https://api.example.com/users/1")
    .AddJson(updatePayload.Serialize())
    .PutAsync();
```

### DELETE

```csharp
var response = await HttpHelper
    .NewRequest("https://api.example.com/users/1")
    .AddParameter("id", "1")
    .DeleteAsync();

// 或直接使用 HttpRequestModel
var response = await new HttpRequestModel("https://api.example.com/users/1").DeleteAsync();
```

### 响应处理

```csharp
response.EnsureSuccessStatusCode();              // 非 2xx 抛异常
string text    = await response.ReadAsStringAsync();
Stream stream  = await response.ReadAsStreamAsync();
T obj          = await response.GetResponseDataAsync<T>();  // 反序列化 JSON
```

---

## 邮件（EmailHelper）

```csharp
// 全局配置（一次）
EmailHelper.SetConfig(new EmailConfig
{
    Host = "smtp.qq.com",
    Port = 587,
    Sender = "me@qq.com",
    SenderPassword = "authcode",
    SenderDisplayName = "My App",
    UseSSL = true
});

// 发送
await new EmailContent(
    to: ["recipient@example.com"],
    subject: "Test Subject",
    body: "<h1>Hello</h1>",
    isHtml: true,
    attachments: [new EmailAttachment("report.pdf", pdfBytes)]
).SendAsync();
```

---

## TCP（TcpHelper）

```csharp
// 服务端
var listener = TcpHelper.CreateListener<TMetadata>(
    IPAddress.Loopback, port,
    adapter: TcpAdapters.FixedHeader  // 固定帧头适配器，防粘包
);
listener.SessionAdded += (s, e) =>
{
    e.Session.Received += (s2, e2) =>
    {
        string msg = e2.Bytes.Utf8Encode();
        e.Session.Send("pong".Utf8Decode());
    };
};
listener.StartListen();

// 客户端
var client = TcpHelper.CreateClient(IPAddress.Loopback, port,
    adapter: TcpAdapters.FixedHeader);
client.Received += (s, e) => Console.WriteLine(e.Bytes.Utf8Encode());
client.StartConnectAndReceive();
client.Send("ping".Utf8Decode());

// 获取可用端口
int port = TcpHelper.GetAvailableTcpPort(8000, 9000);
```

**TcpSession\<TMetadata\> 主要成员**：

| 成员 | 说明 |
|------|------|
| `TMetadata? Metadata` | 会话附加数据（可读写） |
| `void Send(byte[])` | 发送数据 |
| `event Received` | 接收数据事件 |
| `void Close()` | 关闭会话 |

---

## UDP（UdpHelper）

```csharp
// 服务端
var server = UdpHelper.CreateServer(port: 9000);
server.DataReceived += (s, e) =>
{
    Console.WriteLine($"收到来自 {e.RemoteEndPoint}: {e.Bytes.Utf8Encode()}");
    server.Send(e.RemoteEndPoint, "reply".Utf8Decode());
};
server.StartReceive();

// 客户端
var client = UdpHelper.CreateClient(serverEndPoint);
client.DataReceived += (s, e) => Console.WriteLine(e.Bytes.Utf8Encode());
client.StartReceive();
client.Send("hello".Utf8Decode());
```

---

## 文档索引（doc/）

| 文件 | 对应功能 |
|------|---------|
| `utf8.md` / `base64.md` / `hex.md` / `url.md` / `base64url.md` | 编码转换 |
| `md5.md` / `hmacmd5.md` / `sha.md` / `hmacsha.md` | 哈希 |
| `json.md` | JSON 序列化 |
| `string.md` | 字符串扩展 |
| `file.md` | 文件操作 |
| `collection.md` | 集合扩展 |
| `tree.md` | 树形结构 |
| `reflection.md` | 反射工具 |
| `time.md` | 时间工具 |
| `clone.md` / `random.md` / `process.md` | 其他基础工具 |
| `nullcheck.md` | 空值断言 |
| `dto.md` / `request.md` / `response.md` | 模型 |
| `datatable.md` | DataTable 扩展 |
| `enum.md` | 枚举工具 |
| `compression.md` / `decompression.md` | 压缩解压 |
| `symmetric.md` / `rsakey.md` / `jwt.md` / `x509.md` | 加解密 |
| `sql.md` | 数据库 |
| `excel.md` / `spreadsheet.md` | Excel |
| `http-get.md` / `http-post.md` / `http-put.md` / `http-delete.md` | HTTP |
| `email.md` | 邮件 |
| `tcp.md` / `udp.md` | TCP / UDP |
